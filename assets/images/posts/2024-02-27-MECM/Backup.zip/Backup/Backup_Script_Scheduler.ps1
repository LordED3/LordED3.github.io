# Backup Script Scheduler

# Task action
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "C:\Users\Divine\Desktop\Backup\Backup_Script.ps1"

# Task trigger (every day at 12 AM)
$trigger = New-ScheduledTaskTrigger -Daily -At 12am

# Specify the Microsoft account email address as the username
$username = "ekpe.divine@outlook.com" # Replace with your actual Microsoft account email address

# Register the scheduled task
Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "DailyBackupTask" -User $username -Password "1708" -Force

Write-Host "Scheduled task created successfully."
