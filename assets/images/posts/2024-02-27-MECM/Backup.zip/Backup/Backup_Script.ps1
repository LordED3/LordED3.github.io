# Source and destination paths
$sourcePath1 = "C:\Users\Divine\Desktop\CODE"
$sourcePath2 = "C:\Users\Divine\Desktop\SomePDFs"
$destinationPath = "D:\Backup"

# Copy files from source to destination, replacing duplicates
Copy-Item -Path $sourcePath1 -Destination $destinationPath -Recurse -Force
Copy-Item -Path $sourcePath2 -Destination $destinationPath -Recurse -Force

Write-Host "Files copied successfully."
